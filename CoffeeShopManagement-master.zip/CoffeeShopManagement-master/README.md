# CoffeeShopManagement



 
the password and username is admin and admin respectively
in This project you can add the user
you can add coffee its size volume and rate
and you can keep the record of overall sale record 
and you can even print bill for customer 
