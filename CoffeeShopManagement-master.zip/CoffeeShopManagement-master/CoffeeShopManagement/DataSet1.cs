﻿namespace CoffeeShopManagement
{


    partial class DataSet1
    {
    }
}