﻿namespace Coursework
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.fName = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.Label();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.lName = new System.Windows.Forms.Label();
            this.textlName = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textDOB = new System.Windows.Forms.DateTimePicker();
            this.Gender = new System.Windows.Forms.Label();
            this.comboGender = new System.Windows.Forms.ComboBox();
            this.errorTxt = new System.Windows.Forms.ErrorProvider(this.components);
            this.dataGridStudents = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.errorTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridStudents)).BeginInit();
            this.SuspendLayout();
            // 
            // fName
            // 
            this.fName.AutoSize = true;
            this.fName.Location = new System.Drawing.Point(52, 24);
            this.fName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.fName.Name = "fName";
            this.fName.Size = new System.Drawing.Size(57, 13);
            this.fName.TabIndex = 0;
            this.fName.Text = "First Name";
            this.fName.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(41, 221);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(56, 19);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(114, 24);
            this.txtfName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtfName.Name = "txtfName";
            this.txtfName.Size = new System.Drawing.Size(76, 20);
            this.txtfName.TabIndex = 3;
            this.txtfName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            this.txtfName.Validating += new System.ComponentModel.CancelEventHandler(this.textfName_Validating);
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(52, 100);
            this.Email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(32, 13);
            this.Email.TabIndex = 6;
            this.Email.Text = "Email";
            // 
            // DOB
            // 
            this.DOB.AutoSize = true;
            this.DOB.Location = new System.Drawing.Point(52, 125);
            this.DOB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(30, 13);
            this.DOB.TabIndex = 7;
            this.DOB.Text = "DOB";
            this.DOB.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Phone
            // 
            this.Phone.AutoSize = true;
            this.Phone.Location = new System.Drawing.Point(52, 151);
            this.Phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(58, 13);
            this.Phone.TabIndex = 8;
            this.Phone.Text = "Phone No.";
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(114, 100);
            this.textEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(76, 20);
            this.textEmail.TabIndex = 10;
            this.textEmail.Validating += new System.ComponentModel.CancelEventHandler(this.textEmail_Validating);
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(114, 151);
            this.textPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(76, 20);
            this.textPhone.TabIndex = 12;
            this.textPhone.Validating += new System.ComponentModel.CancelEventHandler(this.textPhone_Validating);
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.Location = new System.Drawing.Point(52, 53);
            this.lName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(58, 13);
            this.lName.TabIndex = 13;
            this.lName.Text = "Last Name";
            // 
            // textlName
            // 
            this.textlName.Location = new System.Drawing.Point(115, 53);
            this.textlName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textlName.Name = "textlName";
            this.textlName.Size = new System.Drawing.Size(76, 20);
            this.textlName.TabIndex = 14;
            this.textlName.TextChanged += new System.EventHandler(this.textlName_TextChanged);
            this.textlName.Validating += new System.ComponentModel.CancelEventHandler(this.textlName_Validating);
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(52, 74);
            this.address.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(45, 13);
            this.address.TabIndex = 15;
            this.address.Text = "Address";
            this.address.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(114, 75);
            this.textAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textAddress.Name = "textAddress";
            this.textAddress.Size = new System.Drawing.Size(76, 20);
            this.textAddress.TabIndex = 16;
            this.textAddress.Validating += new System.ComponentModel.CancelEventHandler(this.textAddress_Validating);
            // 
            // textDOB
            // 
            this.textDOB.Location = new System.Drawing.Point(114, 125);
            this.textDOB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textDOB.Name = "textDOB";
            this.textDOB.Size = new System.Drawing.Size(151, 20);
            this.textDOB.TabIndex = 17;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Location = new System.Drawing.Point(52, 178);
            this.Gender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(42, 13);
            this.Gender.TabIndex = 18;
            this.Gender.Text = "Gender";
            this.Gender.Click += new System.EventHandler(this.Gender_Click);
            // 
            // comboGender
            // 
            this.comboGender.FormattingEnabled = true;
            this.comboGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.comboGender.Location = new System.Drawing.Point(114, 176);
            this.comboGender.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboGender.Name = "comboGender";
            this.comboGender.Size = new System.Drawing.Size(92, 21);
            this.comboGender.TabIndex = 19;
            // 
            // errorTxt
            // 
            this.errorTxt.ContainerControl = this;
            // 
            // dataGridStudents
            // 
            this.dataGridStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridStudents.Location = new System.Drawing.Point(290, 22);
            this.dataGridStudents.Name = "dataGridStudents";
            this.dataGridStudents.Size = new System.Drawing.Size(700, 228);
            this.dataGridStudents.TabIndex = 21;
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 366);
            this.Controls.Add(this.dataGridStudents);
            this.Controls.Add(this.comboGender);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.textDOB);
            this.Controls.Add(this.textAddress);
            this.Controls.Add(this.address);
            this.Controls.Add(this.textlName);
            this.Controls.Add(this.lName);
            this.Controls.Add(this.textPhone);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtfName);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.fName);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridStudents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label DOB;
        private System.Windows.Forms.Label Phone;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.TextBox textlName;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.DateTimePicker textDOB;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.ComboBox comboGender;
        private System.Windows.Forms.ErrorProvider errorTxt;
        private System.Windows.Forms.DataGridView dataGridStudents;
    }
}