﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coursework
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
            BindGrid();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void StudentForm_Load(object sender, EventArgs e)
        {

        }

        private void LastName_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (textPhone.Text.ToString().Length == 10)
            {
                Student obj = new Student();
                string fName = txtfName.Text;
                string lName = textlName.Text;
                obj.Name = fName + " " + lName;
                obj.Address = textAddress.Text;
                obj.Email = textEmail.Text;
                obj.BirthDate = textDOB.Value;
                obj.ContactNo = textPhone.Text;
                obj.Gender = comboGender.SelectedItem.ToString();

                obj.Add(obj);
            }
            else
            {
                string message = "Please enter valid phone number.";
                string title = "ERROR, susta manasthati cha ho?";
                MessageBox.Show(message, title);
            }
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void Gender_Click(object sender, EventArgs e)
        {

        }

        private void textId_TextChanged(object sender, EventArgs e)
        {

        }

        private void textEmail_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textEmail.Text))
            {
                e.Cancel = true;
                textEmail.Focus();
                errorTxt.SetError(textEmail, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(textEmail, "");
            }
        }

        private void textfName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtfName.Text))
            {
                e.Cancel = true;
                txtfName.Focus();
                errorTxt.SetError(txtfName, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtfName,"");
            }
        }

        private void textlName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textlName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textlName.Text))
            {
                e.Cancel = true;
                textlName.Focus();
                errorTxt.SetError(textlName, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(textlName, "");
            }
        }

        private void textAddress_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textAddress.Text))
            {
                e.Cancel = true;
                textAddress.Focus();
                errorTxt.SetError(textAddress, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(textAddress, "");
            }
        }

        private void textPhone_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textPhone.Text))
            {
                e.Cancel = true;
                textPhone.Focus();
                errorTxt.SetError(textPhone, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(textPhone, "");
            }
        }

        private void BindGrid()
        {
            Student obj = new Student();
            List<Student> listStudents = obj.List();
            DataTable dt = Utility.ConvertToDataTable(listStudents);
            dataGridStudents.DataSource = dt;
        }

    }
}
